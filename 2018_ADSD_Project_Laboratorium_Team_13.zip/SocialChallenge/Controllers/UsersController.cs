﻿using Data;
using Data.DataForms;
using DataLibrary.Logic;
using MySql.Data.MySqlClient;
using SocialChallenge.Methods;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Web.Http;
using ClientUserModel = Data.CreateForms.User;

namespace SocialChallenge.Controllers
{
    public class UsersController : ApiController
    {

        private List<User> Users { get; set; }

        // GET: api/Users
        [OverrideAuthentication]
        [OverrideAuthorization]
        public IEnumerable<User> GetList()
        {
            Users = UserProcessor.LoadUsers();
            return Users;
        }

        // GET: api/Users/5
        [OverrideAuthentication]
        [OverrideAuthorization]
        public IEnumerable<User> GetUserByID(int id)
        {
            User user = new User();
            user = UserProcessor.LoadUserById(id);
            yield return user;
        }

        // GET: api/Users/Henk
        [OverrideAuthentication]
        [OverrideAuthorization]
        public IEnumerable<User> GetUserByName(string username)
        {
            User user = new User();
            user = UserProcessor.LoadUserByUsername(username);
            yield return user;
        }


        // GET: api/users/username
        [OverrideAuthentication]
        [OverrideAuthorization]
        public IEnumerable<User> GetUserLogin(string username, string password)
        {
            User dbUser = UserProcessor.LoadUserByUsername(username);

            if (Password.Confirm(password, dbUser.PasswordHash, dbUser.Salt))
            {
                yield return dbUser;
            }
            else
            {
                yield return null;
            }

        }
        [OverrideAuthentication]
        [OverrideAuthorization]
        [Route("api/Codes")]
        public IEnumerable<Code> getCodes()
        {
            return CodeProcessor.GetCodes();
        }
        // POST: api/Users
        [OverrideAuthentication]
        [OverrideAuthorization]
        public void Post(ClientUserModel user)
        {
            bool firstTeamMember = false;
            string teamName = "";

            // Firstly confirm the registrationcode is valid when not the first signup. If it is we will receive the teamid and access_level
            // Set the accesslevel to admin by default. This is changed with the code, and it wont when no code is available, always making the first person admin
            Constants.AccessLevel accessLevel = Constants.AccessLevel.Admin;
            int? teamId = null;
            Team team = new Team();

            // If the team we load later is unavailable, this bool with turn true
            bool TeamIsUnavailable = false;

            Code code = CodeProcessor.GetCodeById(user.Code);

            // Update the access level and teamid
            accessLevel = code.Access_level;
            teamId = code.TeamId;



            EncryptedPassword encryptedPassword = Password.HashAndSalt(user.Password);
            int lastId;

            try
            {
                // Add the user to the used code's userId's
                lastId = UserProcessor.CreateUser(user.Username, user.Firstname, user.Insertion, user.Lastname, encryptedPassword.HashedPassword, encryptedPassword.Salt, accessLevel, teamId);
                try
                {
                    CodeProcessor.AddUserIdtoCode(user.Code, lastId);
                }
                catch (Exception exception)
                {
                }
            }
            catch (Exception exception)
            {
                // Check if the username is already in use, and inform the user

            }




        }
        [HttpPost]
        [Route("api/studentcode")]
        public void PostSCode(Data.CreateForms.Code code)
        {
            CodeProcessor.CreateCode((Constants.AccessLevel)code.access_level, code.TeamId);
            bool newTeamCreated = false;
            if (code.TeamId != null)
            {
                Team team = new Team();
                try
                {
                    team = TeamProcessor.LoadTeamByTeamId((int)code.TeamId);
                }
                catch (Exception exception)
                {
                }

                if (team == null)
                {
                    try
                    {
                        TeamProcessor.CreateTeam($"Team{code.TeamId}", code.TeamId);
                    }
                    catch (Exception exception)
                    {

                    }

                    newTeamCreated = true;
                }
            }
        }

        [HttpPost]
        [Route("api/teachercode")]
        public void PostDCode(Data.CreateForms.Code code)
        {
            CodeProcessor.CreateCode((Constants.AccessLevel)code.access_level, code.TeamId);
        }

        // PUT: api/Users/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Users/5
        public void Delete(int id)
        {
        }

        [HttpGet]
        [Authorize]
        [Route("api/GetUserClaims")]
        public User GetUserClaims()
        {
            var identityClaims = (ClaimsIdentity)User.Identity;
            IEnumerable<Claim> claims = identityClaims.Claims;
            User model = new User()
            {
                Username = identityClaims.FindFirst("Username").Value,
                Firstname = identityClaims.FindFirst("Firstname").Value,
                Lastname = identityClaims.FindFirst("Lastname").Value,
                TeamId = int.Parse(identityClaims.FindFirst("TeamId").Value)
                // LoggedOn = identityClaims.FindFirst("LoggedOn").Value
            };
            return model;
        }
    }
}
