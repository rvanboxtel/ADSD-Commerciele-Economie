﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Data.DataForms;
using DataLibrary.DataAccess;
using DataLibrary.Logic;
using MySql.Data.MySqlClient;

namespace SocialChallenge.Controllers
{
    public class TeamsController : ApiController
    {
        private List<Team> Teams { get; set; }

        // GET: api/Users
        [OverrideAuthentication]
        [OverrideAuthorization]
        public IEnumerable<Team> GetList()
        {
            Teams = TeamProcessor.LoadTeams();
            return Teams;
        }

        // GET: api/Users/5
        [OverrideAuthentication]
        [OverrideAuthorization]
        public IEnumerable<Team> GetTeamById(int id)
        {
            Team team = new Team();
            team = TeamProcessor.LoadTeamByTeamId(id);
            yield return team;
        }

        // POST: api/Teams

        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Teams/5
        [OverrideAuthentication]
        [OverrideAuthorization]
        public void PutRevenue(Team team)
        {
            try
            {
                TeamProcessor.UpdateTeamRevenue(team.Id, team.Revenue);
            }
            catch (MySqlException exception)
            {
                throw exception;
            }
        }
        // DELETE: api/Teams/5
        [OverrideAuthentication]
        [OverrideAuthorization]
        [Route("api/SetTeamNameAndGoal")]
        public void PutNameAndGoal (Team team)
        {
            try
            {
                TeamProcessor.UpdateTeam(team.Id, team.Name, team.Revenue);
            }
            catch (MySqlException exception)
            {
                throw exception;
            }
        }
        public void Delete(int id)
        {
        }
    }
}
