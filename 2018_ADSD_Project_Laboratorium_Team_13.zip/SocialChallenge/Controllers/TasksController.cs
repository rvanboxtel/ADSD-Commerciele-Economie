﻿using System.Collections.Generic;
using System.Web.Http;
using DataLibrary.DataAccess;
using Data.DataForms;
using DataLibrary.Logic;
using MySql.Data.MySqlClient;

namespace SocialChallenge.Controllers
{
    public class TasksController : ApiController
    {
        // GET: api/Tasks
        [OverrideAuthentication]
        [OverrideAuthorization]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Tasks/5
        public string Get(int id)
        {
            return "value";
        }

        // PUT: api/Tasks/5
        [OverrideAuthentication]
        [OverrideAuthorization]
        public void PutApproved(Task task)
        {
            string query = "UPDATE `tasks` SET `done`=@done , `approved`=@approved WHERE `id`=@id";

            List<MySqlParameter> MySqlParameterList = new List<MySqlParameter>
            {
                new MySqlParameter("@done", task.Done), new MySqlParameter("@approved", task.Approved), new MySqlParameter("@id", task.Id)
            };

            try
            {
                MySqlDataAccess.Update(query, MySqlParameterList);
            }
            catch (MySqlException exception)
            {
                throw exception;
            }
        }
        // PUT: api/Tasks/5
        [OverrideAuthentication]
        [OverrideAuthorization]
        public void PutEarned(int id,  Task task)
        {
            string query = "UPDATE `tasks` SET `done`=1 WHERE `id`=@id";

            List<MySqlParameter> MySqlParameterList = new List<MySqlParameter>
            {
              new MySqlParameter("@id", id)
            };

            try
            {
                MySqlDataAccess.Update(query, MySqlParameterList);
            }
            catch (MySqlException exception)
            {
                throw exception;
            }
        }

        public void post(Task task)
        {
            TaskProcessor.CreateTask(task.TeamId, task.Name, task.Description);
        }

        // DELETE: api/Tasks/5
        public void Delete(int id)
        {
        }
    }
}
