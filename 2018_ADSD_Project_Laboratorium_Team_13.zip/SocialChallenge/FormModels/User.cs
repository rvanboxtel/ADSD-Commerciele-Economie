﻿using System.ComponentModel.DataAnnotations;

namespace SocialChallenge.FormModels
{
    public class User
    {
        [Display(Name = "Registratie code")]
        [StringLength(80, MinimumLength = 10, ErrorMessage = "De registratiecode is tussen {2} en {1} characters.")]
        public string Code { get; set; }

        [Display(Name = "Gebruikers naam")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Zorg ervoor dat je gebruikersnaam tussen {1} en {2} characters is.")]
        [Required(ErrorMessage = "Voer een geldige gebruikers naam in.")]
        public string Username { get; set; }

        [Display(Name = "Gebruikers wachtwoord")]
        [DataType(DataType.Password)]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "Zorg ervoor dat je wachtwoord tussen {1} en {2} characters is.")]
        [Required(ErrorMessage = "Voer een geldig gebruikers wachtwoord in.")]
        public string Password { get; set; }

        [Display(Name = "Bevestig wachtwoord")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Wachtwoord bevestiging komt niet overeen met het wachtwoord.")]
        public string ConfirmPassword { get; set; }
    }
}