﻿using Data.DataForms;
using DataLibrary.Logic;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security.OAuth;
using SocialChallenge.Methods;
using SocialChallenge.Models;
using System;
using System.Security.Claims;

namespace SocialChallenge
{
    public class ApplicationOAuthProvider : OAuthAuthorizationServerProvider
    {

        public override async System.Threading.Tasks.Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
        }

        public override async System.Threading.Tasks.Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            var userStore = new UserStore<ApplicationUser>(new ApplicationDbContext());
            var manager = new UserManager<ApplicationUser>(userStore);
            Data.DataForms.User dbUser = UserProcessor.LoadUserByUsername(context.UserName);
            Data.DataForms.User user = null;
            if (Password.Confirm(context.Password, dbUser.PasswordHash, dbUser.Salt))
            {
                user = dbUser;
                if (user.TeamId == null)
                {
                    user.TeamId = 0;
                }
            }
            if (user != null)
            {
                var identity = new ClaimsIdentity(context.Options.AuthenticationType);
                identity.AddClaim(new Claim("Username", user.Username));
                identity.AddClaim(new Claim("Firstname", user.Firstname));
                identity.AddClaim(new Claim("Lastname", user.Lastname));
                identity.AddClaim(new Claim("Access_level", user.Access_level.ToString()));
                identity.AddClaim(new Claim("TeamId", user.TeamId.ToString()));
                identity.AddClaim(new Claim("LoggedOn", DateTime.Now.ToString()));
                context.Validated(identity);
            }
            else
                return;
        }
    }
}