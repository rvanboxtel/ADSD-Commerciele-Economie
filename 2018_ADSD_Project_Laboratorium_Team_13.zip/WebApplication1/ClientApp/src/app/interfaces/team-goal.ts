export interface TeamGoal {
  id: number;
  team: number;
  raised: number;
  goal: number;

}