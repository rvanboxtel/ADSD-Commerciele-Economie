export interface TeamActivity {
  id: number;
  team: number;
  name: string;
  description: string;
  done: boolean;
}