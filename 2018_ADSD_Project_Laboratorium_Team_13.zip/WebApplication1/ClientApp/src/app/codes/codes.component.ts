import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { UserService } from '../services/user.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-codes',
  templateUrl: './codes.component.html',
  styleUrls: ['./codes.component.scss']
})
export class CodesComponent implements OnInit {
  private readonly rootUrl = 'http://localhost:54858';
  constructor(
    private http: HttpClient,
    private toastr: ToastrService,
    private user: UserService
  ) {}
  codes;
  ngOnInit() {
    this.getCodes();
  }
  getCodes() {
    const reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
    this.http
      .get(this.rootUrl + '/api/codes', {
        headers: reqHeader
      })
      .map(res => res)
      .subscribe((data: any) => {
        this.codes = data;
        console.log(data);
      });
  }
  newStudentCode(e) {
    e.preventDefault();
    const teamid = e.target.elements[0].value;
    if (teamid > 0) {
      const code = { access_level: 0, TeamId: teamid };

      return this.http
        .post(this.rootUrl + '/api/studentcode', code)
        .subscribe(() => {
          this.toastr.success('new code succesfully made');
          this.codes = null;
          this.getCodes();
        });
    } else if (teamid == null) {
      this.toastr.info(`You can't make an code without an team`);
    } else if (teamid == 0) {
      this.toastr.info(`Your teamnummber must atleast be higher then 1`);
    }
  }

  NewTeacherCode() {
    const code = { access_level: 2, TeamId: 0 };
    return this.http
      .post(this.rootUrl + '/api/teachercode', code)
      .subscribe(
        () => {
        this.toastr.success('new code succesfully made');
        this.codes = null;
        this.getCodes();
      });
  }
  copyText(val: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = val;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.toastr.success('Link succesvol gecopierd');
  }
}
