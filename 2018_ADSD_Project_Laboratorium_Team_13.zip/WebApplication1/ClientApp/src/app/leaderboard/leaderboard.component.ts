import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { ActivatedRoute } from '@angular/router';
import { PlotBand } from '@progress/kendo-angular-charts';
import { TeamGoal } from '../interfaces/team-goal';
import { TeamActivity } from '../interfaces/team-activities';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { GridDataResult } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-leaderboard',
  templateUrl: './leaderboard.component.html',
  styleUrls: ['./leaderboard.component.scss']
})
export class LeaderboardComponent implements OnInit {
  public hidden: any = { visible: false };
  public shown: any = { visible: true };

  public moneyPlotBands: PlotBand[] = [];
  public activityPlotBands: PlotBand[] = [
    { from: 0, to: 100, color: '#ccc', opacity: 1 }
  ];
  teamName = '';
  public teams: any[] = [];
  public money: any[] = [];
  public activity: any[] = [[0, 0]];
  public sortMoney: SortDescriptor[] = [
    {
      field: 'Revenue',
      dir: 'desc'
    }
  ];
  public sortActivities: SortDescriptor[] = [
    {
      field: 'totalfinishedPerc',
      dir: 'desc'
    }
  ];
  public gridView: GridDataResult;
  public gridView2: GridDataResult;

  constructor(private teamData: DataService, private route: ActivatedRoute) {}

  ngOnInit() {
    this.getTeams();
  }

  public onTabSelect(e) {
    console.log(e);
  }

  getTeams() {
    let teams;
    this.teamData.getTeams().subscribe(data => {
      teams = data;
      for (const team of teams) {
        const totalFinishedPerc = this.calculateTeamFinishedTaskPercentage(
          team.Tasks
        );
        const totalFinished = this.calculateTeamFinished(team.Tasks);
        // tslint:disable-next-line: max-line-length
        this.teams.push({
          Id: team.Id,
          Name: team.Name,
          Charitygoal: team.Charitygoal,
          Tasks: team.Tasks,
          Users: team.Users,
          Revenue: team.Revenue,
          totalfinished: totalFinished,
          totalfinishedPerc: totalFinishedPerc,
          money: [team.Revenue, team.Charitygoal],
          activities: [totalFinishedPerc, 100],
          moneyPlotBands: [
            { from: 0, to: team.Charitygoal, color: '#ccc', opacity: 1 }
          ]
        });
      }
      this.loadTop5Money();
      this.loadTop5Activities();
    });
  }

  private loadTop5Money(): void {
    this.gridView = {
      data: orderBy(this.teams, this.sortMoney),
      total: this.teams.length
    };
  }

  private loadTop5Activities(): void {
    this.gridView2 = {
      data: orderBy(this.teams, this.sortActivities),
      total: this.teams.length
    };
  }

  calculateTeamFinished(tasks) {
    let finished = 0;
    for (const task of tasks) {
      // tslint:disable-next-line: no-unused-expression
      if (task.Done === 1) {
        finished += 1;
      }
    }
    return finished;
  }
  calculateTeamFinishedTaskPercentage(tasks) {
    let percentage = 0;
    for (const task of tasks) {
      // tslint:disable-next-line: no-unused-expression
      if (task.Done === 1) {
        percentage += 1;
      }
    }
    const percentageCalc = (percentage / tasks.length) * 100;
    return percentageCalc;
  }
}
