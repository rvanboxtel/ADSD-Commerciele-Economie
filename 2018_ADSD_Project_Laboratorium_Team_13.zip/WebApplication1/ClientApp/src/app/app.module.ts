import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NavComponent } from './nav/nav.component';
import { LoginComponent } from './login/login.component';
import { NotificationModule } from '@progress/kendo-angular-notification';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DashboardComponent } from './team/dashboard/dashboard.component';
import { GridModule } from '@progress/kendo-angular-grid';
import { ChartsModule } from '@progress/kendo-angular-charts';
import 'hammerjs';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DataService } from './services/data.service';
import { UserService } from './services/user.service';
import { AuthGuard } from './services/auth.guard';
import { ScrollViewModule } from '@progress/kendo-angular-scrollview';
import { LeaderboardComponent } from './leaderboard/leaderboard.component';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { TeamsComponent } from './team/teams/teams.component';
import { AuthInterceptor } from './services/auth.interceptor';
import { ToastrModule } from 'ngx-toastr';
import { RegisterComponent } from './register/register.component';
import { CodesComponent } from './codes/codes.component';
import { AuthAdminGuard } from './services/authAdmin.guard';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavComponent,
    LoginComponent,
    DashboardComponent,
    LeaderboardComponent,
    TeamsComponent,
    RegisterComponent,
    CodesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NotificationModule,
    BrowserAnimationsModule,
    InputsModule,
    ButtonsModule,
    GridModule,
    ChartsModule,
    HttpClientModule,
    ScrollViewModule,
    LayoutModule,
    DialogsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      progressBar: true
    }),
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    DataService,
    UserService,
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    AuthAdminGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
