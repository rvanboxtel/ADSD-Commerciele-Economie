import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { MessageService } from './message.service';
import { TeamGoal } from '../interfaces/team-goal';
import { TeamActivity } from '../interfaces/team-activities';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private api = 'http://localhost:54858/api/';
  MoneyUrl = 'assets/Raised.json';
  ActivitiesUrl = 'assets/Activities.json';
  constructor(
    private http: HttpClient,
    private messageService: MessageService
  ) {}

  getTeamGoals(teamid: number): Observable<TeamGoal[]> {
    const url = `${this.MoneyUrl}/?team=${teamid}`;
    return this.http.get<TeamGoal[]>(url).pipe(
      tap(_ => this.log('fetched goals')),
      catchError(this.handleError<TeamGoal[]>('getTeamGoals', []))
    );
  }

  getMoneyRaised(): Observable<TeamGoal[]> {
    return this.http.get<TeamGoal[]>(this.MoneyUrl).pipe(
      tap(_ => this.log('fetched Money')),
      catchError(this.handleError<TeamGoal[]>('getMoneyRaised', []))
    );
  }

  getTeamActivities(teamid: number): Observable<TeamActivity[]> {
    return this.http
      .get<TeamActivity[]>(`${this.ActivitiesUrl}/?team=${teamid}`)
      .pipe(
        tap(_ => this.log(`found activities matching "${teamid}"`)),
        catchError(this.handleError<TeamActivity[]>('getTeamActivities', []))
      );
  }

  getTeams() {
    const reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
    return this.http
      .get(this.api + 'teams', { headers: reqHeader })
      .map((res: Response) => res);
  }

  getTeam(id: number) {
    const reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
    return this.http.get(this.api + 'teams/' + id,  { headers: reqHeader }).map((res: Response) => res);
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.log(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  /** Log a DataService message with the MessageService */
  private log(message: string) {
    this.messageService.add(`DataService: ${message}`);
  }
}
