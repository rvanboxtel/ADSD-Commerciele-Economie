import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router
} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { UserService } from './user.service';
import { toDataSourceRequest } from '@progress/kendo-data-query';

@Injectable({
  providedIn: 'root'
})
export class AuthAdminGuard implements CanActivate {
  // authenticatie
  constructor(private user: UserService, private router: Router) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    if (localStorage.getItem('userToken') != null) {
      const loggedIn = this.user.getUserLoggedIn();
      if (loggedIn === true) {
        const user = this.user.user;
        if (user.Access_level <= 1) {
          return false;
        }
        if (user.Access_level === 2) {
          return true;
        }
      }
    }
    this.router.navigate(['/login']);
    return false;
  }
}
