export class User {
  UserName: string;
  FirstName: string;
  Insertion: string;
  LastName: string;
  Password: string;
}
