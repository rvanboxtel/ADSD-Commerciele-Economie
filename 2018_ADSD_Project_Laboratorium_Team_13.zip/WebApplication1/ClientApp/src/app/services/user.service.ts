import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { User } from './user.model';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient,
    private toastr: ToastrService
  ) {
    this.isUserLoggedIn = false;
  }
  // Om in te loggen is dit nodig
  private isUserLoggedIn;
  readonly rootUrl = 'http://localhost:54858';
  public username;
  private password;
  user;
  private apiUrl = 'http://localhost:54858/api/users/';
  formModel = this.fb.group({
    UserName: ['', Validators.required],
    Firstname: [''],
    Insertion: [''],
    Lastname: [''],
    Passwords: this.fb.group(
      {
        Password: ['', [Validators.required, Validators.minLength(8)]],
        ConfirmPassword: ['', Validators.required]
      },
      { validator: this.comparePasswords }
    )
  });
  // constructor(private http: HttpClient, private router: Router) {
  //   this.isUserLoggedIn = false;
  // }
  getUserLoggedIn() {
    if (localStorage.getItem('userToken') != null) {
      this.isUserLoggedIn = true;
      this.getUserClaims();
      return this.isUserLoggedIn;
    }
    return this.isUserLoggedIn;
  }
  comparePasswords(fb: FormGroup) {
    const confirmPswrdCtrl = fb.get('ConfirmPassword');
    // passwordMismatch
    // confirmPswrdCtrl.errors={passwordMismatch:true}
    if (
      confirmPswrdCtrl.errors == null ||
      'passwordMismatch' in confirmPswrdCtrl.errors
    ) {
      if (fb.get('Password').value !== confirmPswrdCtrl.value) {
        confirmPswrdCtrl.setErrors({ passwordMismatch: true });
      } else {
        confirmPswrdCtrl.setErrors(null);
      }
    }
  }

  setUserLoggedOut() {
    this.isUserLoggedIn = false;
    this.username = '';
  }

  getUserLogin(user, password) {
    this.http
      .get(this.apiUrl + '?username=' + user + '&password=' + password)
      .map(res => res)
      .subscribe(data => {
        this.user = data;
        if (this.user !== null) {
          this.isUserLoggedIn = true;
        }
      });
  }

  registerUser(code: string) {
    let dcode;
    const reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
    this.http
      .get(this.rootUrl + '/api/codes', {
        headers: reqHeader
      })
      .map(res => res)
      .subscribe((data: any) => {
        const tcode = data.findIndex((x: any) => x.Id === code);

        if (tcode === -1) {
          this.toastr.error('This code does no longer exist', 'Invalid code');
        }
        if (tcode => 0) {
          dcode = data[tcode];
          console.log(dcode);
        }
      });
    const body = {
      Code: code,
      UserName: this.formModel.value.UserName,
      FirstName: this.formModel.value.Firstname,
      Insertion: this.formModel.value.Insertion,
      LastName: this.formModel.value.Lastname,
      Password: this.formModel.value.Passwords.Password
    };

    return this.http.post(this.rootUrl + '/api/Users', body, {
      headers: reqHeader
    });
  }

  setLoggedIn() {
    return (this.isUserLoggedIn = true);
  }

  login(formData) {
    const data =
      'username=' +
      formData.UserName +
      '&password=' +
      formData.Password +
      '&grant_type=password';
    const reqHeader = new HttpHeaders({
      'Content-Type': 'application/x-www-urlencoded',
      'No-Auth': 'True'
    });
    return this.http.post(this.rootUrl + '/token', data, {
      headers: reqHeader
    });
  }

  getUserClaims() {
    this.http
      .get(this.rootUrl + '/api/GetUserClaims')
      .map(res => res)
      .subscribe((data: any) => {
        if (data.TeamId === 0) {
          data.Access_level = 2;
        }
        this.user = data;
      });
  }

  Logout() {
    localStorage.removeItem('userToken');
    this.setUserLoggedOut();
    this.router.navigate(['/']);
  }
}
