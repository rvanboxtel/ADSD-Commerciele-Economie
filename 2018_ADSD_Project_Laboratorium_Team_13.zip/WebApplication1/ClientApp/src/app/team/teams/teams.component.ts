import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-teams',
  templateUrl: './teams.component.html',
  styleUrls: ['./teams.component.scss']
})
export class TeamsComponent implements OnInit {
  public teams: any[] = [];
  constructor(private teamData: DataService) {}

  ngOnInit() {
    this.getTeams();
  }
  getTeams() {
    let teams;
    this.teamData.getTeams().subscribe(data => {
      teams = data;
      for (const team of teams) {
        const needApproval = this.needApprovalCalc(team.Tasks);
        // tslint:disable-next-line: max-line-length
        this.teams.push({
          Id: team.Id,
          Name: team.Name,
          revenue: team.Revenue,
          Charitygoal: team.Charitygoal,
          Tasks: team.Tasks,
          Users: team.Users,
          needApproval
        });
      }
    });
  }
  needApprovalCalc(Tasks: any) {
    let total = 0;
    for (const task of Tasks) {
      if (task.Done === 1 && task.Approved === 0) {
        total += 1;
      }
    }
    return total;
  }
}
