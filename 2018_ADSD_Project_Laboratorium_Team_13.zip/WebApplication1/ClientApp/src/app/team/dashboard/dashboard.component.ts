import { Component, OnInit } from '@angular/core';
import { PlotBand } from '@progress/kendo-angular-charts';
import { DataService } from 'src/app/services/data.service';
import { TeamGoal } from 'src/app/interfaces/team-goal';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserService } from 'src/app/services/user.service';
import { ToastrModule, ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  activitiesRejected = 0;
  constructor(
    private router: Router,
    private teamData: DataService,
    private user: UserService,
    private http: HttpClient,
    private route: ActivatedRoute,
    private toastr: ToastrService
  ) {}
  public hidden: any = { visible: false };
  public shown: any = { visible: true };
  currentUser;

  public moneyPlotBands: PlotBand[] = [
    { from: 0, to: 0, color: '#ccc', opacity: 1 }
  ];
  public activityPlotBands: PlotBand[] = [
    { from: 0, to: 100, color: '#ccc', opacity: 1 }
  ];
  activitiesColor = 'green';
  teamName = '';
  public money: any[] = [[0, 0]];
  public activity: any[] = [[0, 0]];
  goals: TeamGoal[];
  goalsData: any[];
  activities: any[] = [];
  activitiesApproved = 0;
  activitiesFinished = 0;
  activitiesMax = 100;
  activeTeam;
  teamTotal = 0;
  public dialogOpened = false;
  public windowOpened = false;
  public window2Opened = false;
  public earnedWindow = 0;
  private api = 'http://localhost:54858/api/';

  public close(component) {
    this[component + 'Opened'] = false;
  }

  public open2(component) {
    this.window2Opened = true;
  }

  public open(component, team) {
    this[component + 'Opened'] = true;
    this.earnedWindow = team;
  }

  public action(status) {
    console.log(`Dialog result: ${status}`);
    this.dialogOpened = false;
  }

  ngOnInit() {
    this.getCurrentUser();
    this.getTeam();
  }
  getCurrentUser() {
    const loggedIn = this.user.getUserLoggedIn();
    if (loggedIn === true) {
      this.currentUser = this.user.user;
    }
  }

  public done(task) {
    task.Done = 1;
    this.finishActivity(task.Id, task);
  }

  public approve(task) {
    task.Approved = 1;
    this.approveAcitivty(task);
  }
  public reject(task) {
    task.Approved = 2;
    this.approveAcitivty(task);
  }

  public undo(task) {
    task.Approved = 0;
    this.approveAcitivty(task);
  }
  approveAcitivty(task: any) {
    const reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
    return this.http
      .put(this.api + 'Tasks', task, {
        headers: reqHeader
      })
      .subscribe(
        data => JSON.stringify(data),
        error => this.toastr.error(error, 'An error has occured please try again later'),
        () => {
          this.toastr.success('change succesfully saved')
          this.activities = [];
          this.activitiesFinished = 0;
          this.activitiesApproved = 0;
          this.activitiesRejected = 0;
          this.getTeam();

              }
      );
  }

  public save(e, team) {
    e.preventDefault();
    const earned = parseFloat(e.target.elements[0].value);
    this.close('window');
    if (team.Revenue === null) {
      team.Revenue = earned;
    } else if (team.Revenue > 0) {
      team.Revenue += earned;
    }

    this.addRevenue(team);
  }
  public saveTaak(e, team) {
    e.preventDefault();
    const name = e.target.elements[0].value;
    const descr = e.target.elements[1].value;
    this.close('window2');
    const task = {
      TeamId: team.Id,
      Name: name,
      done: 0,
      approved: 0,
      description: descr
    };
    return this.http.post(this.api + 'Tasks', task).subscribe(
      data => JSON.stringify(data),
      error => this.toastr.error(error, 'An error has occured please try again later'),
      () => {
        this.toastr.success('task succesfully saved');
        this.activities = [];
        this.activitiesFinished = 0;
        this.activitiesApproved = 0;
        this.activitiesRejected = 0;
        this.getTeam();
      }
    );
  }
  addRevenue(team) {
    const reqHeader = new HttpHeaders({});
    return this.http
      .put(this.api + 'Teams', team, {
        headers: reqHeader
      })
      .subscribe(
        data => JSON.stringify(data),
        error => this.toastr.error(error, 'An error has occured please try again later'),
        () => {
          this.activities = [];
          this.activitiesFinished = 0;
          this.activitiesApproved = 0;
          this.activitiesRejected = 0;
          this.getTeam();
        }
      );
  }
  finishActivity(id: any, task: any) {
    const reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
    return this.http
      .put(this.api + 'Tasks/' + id, task, {
        headers: reqHeader
      })
      .subscribe(
        data => JSON.stringify(data),
        error => this.toastr.error(error, 'An error has occured please try again later'),
        () => {
          this.activities = [];
          this.activitiesFinished = 0;
          this.activitiesApproved = 0;
          this.activitiesRejected = 0;
          this.getTeam();
        }
      );
  }
  getTeam() {
    // tslint:disable-next-line: radix
    const team = parseInt(this.route.snapshot.paramMap.get('id'));
    this.teamData.getTeam(team).subscribe(data => {
      // tslint:disable-next-line: triple-equals
      this.activeTeam = data[0];
      this.teamName = this.activeTeam.Name;
      for (const task of this.activeTeam.Tasks) {
        if (task.Done === 1) {
          this.activitiesFinished += 1;
        }
        if (task.Approved === 1) {
          this.activitiesApproved += 1;
        }
        if (task.Approved === 2) {
          this.activitiesRejected += 1;
        }
        if (task !== undefined) {
          this.activities.push(task);
        }
      }
      if (this.activitiesRejected > 0) {
        this.activitiesColor = 'red';
      } else if (this.activitiesFinished === this.activitiesApproved) {
        this.activitiesColor = 'green';
      } else if (this.activitiesFinished >= this.activitiesApproved) {
        this.activitiesColor = 'orange';
      }
      if (this.activities !== undefined) {
        this.activity = [
          [(this.activitiesFinished / this.activities.length) * 100, 100]
        ];
      }

      this.SetTeamMoneyCounter(
        this.activeTeam.Revenue,
        this.activeTeam.Charitygoal
      );
    });
  }

  SetTeamMoneyCounter(revenue, goal) {
    if (revenue >= goal) {
      this.moneyPlotBands[0].to = goal;
      this.money = [[revenue, goal]];
    } else if (revenue <= goal) {
      this.moneyPlotBands[0].to = goal;
      this.money = [[revenue, goal]];
    }
  }
  finish(id) {}
}
