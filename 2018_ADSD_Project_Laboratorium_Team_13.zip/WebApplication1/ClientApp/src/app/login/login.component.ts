import { Component } from '@angular/core';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { HttpErrorResponse } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
// Login component
export class LoginComponent implements OnInit {
  constructor(
    private service: UserService,
    private router: Router,
    private toastr: ToastrService
  ) {}
  isLoginError = false;

  wrong = false;
  notFilled = false;
  formModel = {
    UserName: '',
    Password: ''
  };
  ngOnInit() {
    if (localStorage.getItem('token') != null) {
      this.router.navigateByUrl('/home');
    }
  }
  // om in the loggen
  // loginUser(e) {
  //   e.preventDefault();
  //   const username = e.target.elements[0].value;
  //   const password = e.target.elements[1].value;
  //   if (username !== '' && password !== '') {
  //     this.user.getUserLogin(username, password);
  //     const user = this.user.user;
  //     if (this.user.getUserLoggedIn() === true) {
  //       if (user[0].Access_level === 2) {
  //         this.router.navigate(['teams']);
  //       } else if (user[0].TeamId) {
  //         this.router.navigate(['team/' + user[0].TeamId]);
  //       }
  //     } else if (user !== undefined) {
  //       this.wrong = true;
  //     }
  //   } else {
  //     this.notFilled = true;
  //   }
  // }

  onSubmit(form: NgForm) {
    this.service.login(form.value).subscribe(
      (data: any) => {
        localStorage.setItem('userToken', data.access_token);
        this.service.getUserLogin(form.value.UserName, form.value.Password);
        this.toastr.success('Logged in succesfully', 'logged in');
        this.router.navigate(['/']);
      },
      (err: HttpErrorResponse) => {
        this.isLoginError = true;
      }
    );
  }
}
