import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {
  data: Array<any> = [
    {
      text: 'Team Dashboard',
      icon: 'myspace',
      url: '/team/'
    },
    {
      text: 'Logout',
      icon: 'logout',
      url: '/logout',
      click: () => {
        this.user.Logout();
        this.router.navigate(['/']);
      }
    }
  ];
  userClaims;
  currentUser;
  loggedIn = false;

  constructor(private user: UserService, private router: Router) {}

  ngOnInit() {
    this.loggedIn = this.user.getUserLoggedIn();
  }
  logOut() {
    this.user.Logout();
    this.router.navigate(['/']);
  }

  checkHome() {
    if (this.router.url === '/') {
      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < this.data.length; i++) {
        this.data[i].disabled = false;
      }
      return true;
    } else {
      return false;
    }
  }
  loggedInCheck() {
    if (this.loggedIn === true) {
      this.currentUser = this.user.user;
      if (this.currentUser.TeamId !== null && this.currentUser.TeamId !== 0) {
        this.data[0].text = 'Your Team';
        this.data[0].url = '/team/' + this.currentUser.TeamId;
      }
      if (this.currentUser.Access_level === 2) {
        this.data[0].text = 'All teams';
        this.data[0].url = '/teams';
      }
    }
    return this.loggedIn;
  }

  checkLogin() {
    if (this.router.url === '/login') {
      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < this.data.length; i++) {
        this.data[i].disabled = false;
      }
      return true;
    } else {
      return false;
    }
  }
  checkUrl(url) {
    const index = this.data.findIndex(x => x.url === url);
    if (this.router.url === url) {
      return true;
    } else {
      return false;
    }
  }
}
