import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './team/dashboard/dashboard.component';
import { AuthGuard } from './services/auth.guard';
import { LeaderboardComponent } from './leaderboard/leaderboard.component';
import { TeamsComponent } from './team/teams/teams.component';
import { RegisterComponent } from './register/register.component';
import { CodesComponent } from './codes/codes.component';
import { AuthAdminGuard } from './services/authAdmin.guard';


const routes: Routes = [
  { path: '', component: HomeComponent, pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register/:code', component: RegisterComponent },
  { path: 'team/:id', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'teams', component: TeamsComponent, canActivate: [AuthAdminGuard] },
  { path: 'leaderboard', component: LeaderboardComponent },
  { path: 'codes', component: CodesComponent, canActivate: [AuthAdminGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
