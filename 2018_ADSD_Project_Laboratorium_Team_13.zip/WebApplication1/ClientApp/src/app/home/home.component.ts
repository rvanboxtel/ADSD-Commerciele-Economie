import { Component, OnInit } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { PlotBand } from '@progress/kendo-angular-charts';
import { TeamGoal } from '../interfaces/team-goal';
import { TeamActivity } from '../interfaces/team-activities';
import { DataService } from '../services/data.service';
import { ActivatedRoute } from '@angular/router';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  public hidden: any = { visible: false };
  public shown: any = { visible: true };
  public totalMoney: any[] = [];
  public teams: any[] = [];
  public items: any[] = [{ title: 'MoneyBag', url: 'assets/moneybag.gif' }];
  public width = '100%';
  public height = '400px';
  public activeIndex = 0;
  public raised = 0;
  public goal = 0;
  public moneyPlotBands: PlotBand[] = [
    { from: 0, to: 0, color: '#ccc', opacity: 1 }
  ];
  public activityPlotBands: PlotBand[] = [
    { from: 0, to: 100, color: '#ccc', opacity: 1 }
  ];
  teamName = '';
  public money: any[] = [];
  public activity: any[] = [[0, 0]];
  goals: TeamGoal[];
  goalsData: any[];
  activities: TeamActivity[];
  activitiesData: any[];
  public gridView: GridDataResult;
  public gridView2: GridDataResult;
  activitiesFinished = 0;
  activitiesMax = 100;
  public sortMoney: SortDescriptor[] = [
    {
      field: 'revenue',
      dir: 'desc'
    }
  ];
  userClaims: any;

  constructor(
    private teamData: DataService,
    private userService: UserService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.getTeams();
  }

  getTeams() {
    let teams;
    this.teamData.getTeams().subscribe(data => {
      teams = data;
      for (const team of teams) {
        this.calculateTotalRaised(team.Revenue);
        this.calculateGoal(team.Charitygoal);
        // tslint:disable-next-line: max-line-length
        this.teams.push({
          Id: team.Id,
          Name: team.Name,
          Charitygoal: team.Charitygoal,
          Tasks: team.Tasks,
          Users: team.Users,
          revenue: team.Revenue,
          money: [team.Revenue, team.Charitygoal]
        });
        this.totalMoney = [this.raised, this.goal];
      }

      this.loadTop5Money();
    });
  }

  private loadTop5Money(): void {
    const getTop5 = orderBy(this.teams, this.sortMoney);
    let result: any[] = [];
    for (let i = 0; i < 5; i++) {
      result.push(getTop5[i]);
    }

    this.gridView = {
      data: orderBy(result, this.sortMoney),
      total: this.teams.length
    };
  }
  calculateTotalRaised(revenue) {
    if (revenue != null) {
      this.raised += revenue;
    }
  }
  calculateGoal(charity) {
    this.goal += charity;
  }

  public onTabSelect(e) {}
}
