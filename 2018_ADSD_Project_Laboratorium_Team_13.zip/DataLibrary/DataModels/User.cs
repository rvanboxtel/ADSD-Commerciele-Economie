﻿using System;
using System.ComponentModel.DataAnnotations;
using static DataLibrary.Data.Constants;

namespace DataLibrary.DataModels
{
    public class User
    {
        public int Id { get; set; }

        [Display(Name = "Gebruikersnaam")]
        public string Username { get; set; }

        public DateTime Date_added { get; set; }
        public string PasswordHash { get; set; }
        public string Salt { get; set; }
        public int? TeamId { get; set; }
        public Team Team { get; set; }
        public AccessLevel Access_level { get; set; }
        public StatusType Status { get; set; }
    }
}
