﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using static DataLibrary.Data.Constants;

namespace DataLibrary.DataModels
{
    public class Task
    {
        public int Id { get; set; }

        [Display(Name = "taak")]
        public string Name { get; set; }

        [Display(Name = "descriptie")]
        public string Description { get; set; }

        [Display(Name = "klaar")]
        public TaskProgress Done { get; set; }

        [Display(Name = "goedgekeurd")]
        public TaskStatus Approved { get; set; }

        [Display(Name = "verdiend")]
        public float? Earned { get; set; }
    }
}
