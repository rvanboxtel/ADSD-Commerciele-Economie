﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using static DataLibrary.Data.Constants;

namespace DataLibrary.DataModels
{
    public class Team
    {
        public int Id { get; set; }

        [Display(Name = "Naam")]
        public string Name { get; set; }

        [Display(Name = "Doel")]
        public float? Charitygoal { get; set; }

        public bool FirstTimeNameChangeDone { get; set; }

        [Display(Name = "Teamleden")]
        public List<User> Users { get; set; }

        [Display(Name = "Taken")]
        public List<Task> Tasks { get; set; }
    }
}
